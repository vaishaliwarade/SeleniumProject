package TestSuite;

import org.openqa.selenium.WebDriver;

public class MethodSavingPlan extends Parent {
	
	public WebDriver driver;
	public MethodSavingPlan(WebDriver driver, String firstName) {
	// if creating any object for new class, initilize here, suppose as below�
	}

}
