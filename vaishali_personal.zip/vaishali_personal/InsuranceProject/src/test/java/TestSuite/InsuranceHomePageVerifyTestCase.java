package TestSuite;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import PageObjects.BajajAllianzProductid60020Page;
import resources.Utility;

public class InsuranceHomePageVerifyTestCase extends Utility {

	WebDriver driver;
	
	BajajAllianzProductid60020Page objBA60020Page;

	@BeforeSuite
	public void setUp() throws IOException {
		driver = intializeDriver();
		driver.manage().window().maximize();
	}
	
	@Test
	public void verifyBajajAllianzProduct60020() throws IOException, InterruptedException {

		objBA60020Page = new BajajAllianzProductid60020Page(driver);
				
		driver.getCurrentUrl();
		
		
		if (driver.getCurrentUrl().contains("POS Goal Suraksha_Old")) {

			System.out.println("Page opened Successfully");
		}

		else {
			System.out.println("Page not Opened");
		}

		// driver.findElement(By.cssSelector("input[id='txtLifeAssuredFirstName']")).sendKeys("vaishali");
		// driver.findElement(By.cssSelector("input[id='txtLifeAssuredLastName']")).sendKeys("warade");
		//objBA60020Page.txtFirstName.clear();
		objBA60020Page.txtFirstName.sendKeys("Vaishali");
		//objBA60020Page.txtLastName.clear();
		objBA60020Page.txtLastName.sendKeys("Warade");

		// Select dropdown = new
		// Select(driver.findElement(By.cssSelector("#ddlLI_GENDER")));
		// dropdown.selectByValue("F");

		Select selectGender = new Select(objBA60020Page.selectGender);
		selectGender.selectByValue("F");

		Thread.sleep(1000);

		driver.findElement(By.id("txtAge")).click();

		while (!driver
				.findElement(By.cssSelector("[class='datepicker-years'] [class='table-condensed'] [class='switch']"))
				.getText().contains("1990-1999")) {
			driver.findElement(By.xpath("//div[1]//div[3]//th[1]//i[1]")).click();
		}

		List<WebElement> years = driver.findElements(By.className("year"));
		int count = driver.findElements(By.className("year")).size();
		for (int i = 0; i < count; i++) {
			String text = driver.findElements(By.className("year")).get(i).getText();
			if (text.equalsIgnoreCase("1990")) {
				driver.findElements(By.className("year")).get(i).click();
				break;
			}

		}
		List<WebElement> month = driver.findElements(By.className("month"));
		int count1 = driver.findElements(By.className("month")).size();
		for (int j = 0; j < count1; j++) {
			String text = driver.findElements(By.className("month")).get(j).getText();
			if (text.equalsIgnoreCase("Aug")) {
				driver.findElements(By.className("month")).get(j).click();
				break;
			}

		}
		Thread.sleep(1000);

		List<WebElement> date = driver.findElements(By.className("day"));
		int count2 = driver.findElements(By.className("day")).size();
		for (int k = 0; k < count2; k++) {
			String text = driver.findElements(By.className("day")).get(k).getText();
			if (text.equalsIgnoreCase("5")) {
				driver.findElements(By.className("day")).get(k).click();
				break;
			}

		}

		// driver.findElement(By.id("PinCode")).sendKeys("400701");
		// select pin code
		objBA60020Page.txtPinCode.sendKeys("400701");

		// select Sale Person's state

		// Select state = new Select(driver.findElement(By.id("SalesState")));
		// state.selectByVisibleText("MAHARASHTRA");

		Select state = new Select(objBA60020Page.selectSalesState);
		state.selectByVisibleText("MAHARASHTRA");

		Select PT = new Select(objBA60020Page.selectPT);
		PT.selectByVisibleText("15");

		Select PPT = new Select(objBA60020Page.selectPPT);
		PPT.selectByVisibleText("5");

		Select mode = new Select(objBA60020Page.selecMode);
		mode.selectByVisibleText("Monthly");
		// mode.selectByVisibleText("Annual");

		// driver.findElement(By.id("txtMP")).sendKeys("15000");
		objBA60020Page.txtMP.sendKeys("15000");

		// driver.findElement(By.xpath("//*[@id='contentDiv']/div[6]/div/div/button[2]")).click();

		objBA60020Page.btnGenerateBI.click();

		//Thread.sleep(10000);

		// objBA60020Page.btnDownloadPDF.click();
		
		driver.close();

	}


	@AfterSuite
	public void Close() throws IOException {
		// closeDriver(driver);
	}

}
